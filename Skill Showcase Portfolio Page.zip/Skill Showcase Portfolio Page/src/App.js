import React from 'react';
import './App.css';

function App() {
  return (
    <div className="main-content">
      <header>
        <h1>What I Do</h1>
        <div className="main-articles">
          <p>
            I am a determined young woman who loves IT and is currently in my third year of studying IT software development.
            Even though I haven't worked yet, I've done a lot of projects and assignments that show I am good at what I do.
          </p>
        </div>
      </header>
      <nav>
        <div className="aside-left">
          <h2>Graphic design</h2>
          <img src="./Graphic.png" alt="Graphic" />
          <p>I specialize in creating visually appealing designs that communicate effectively with the audience.</p>
          <footer>
            <span>+ read more</span>
          </footer>
        </div>
      </nav>

      <section>
        <article>
          <h2>Web development</h2>
          <img src="./Web.png" alt="Web" />
          <p>I develop modern and responsive websites using the latest technologies to provide the best user experience.</p>
          <footer>
            <span>+ read more</span>
          </footer>
        </article>
      </section>

      <aside>
        <h2>Marketing</h2>
        <img src="./Marketing.png" alt="Marketing" />
        <p>I employ strategic marketing techniques to help businesses reach their target audience and achieve their goals.</p>
        <footer>
          <span>+ read more</span>
        </footer>
      </aside>
    </div>
  );
}

export default App;
